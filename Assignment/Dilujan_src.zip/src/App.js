import API from './components/Task/API'
import './App.css';

function App() {
  return (
   <>
   <API></API>
   </>
  );
}

export default App;
